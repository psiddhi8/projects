# Project Set 2

For this assignment, I chose to use both symmetric and asymmetric encryption in order to avail of the pros of both methods. 

## Semantic Decisions
For this project, I chose to have `e` or `d` as the first command-line option instead of `-e` or `-d`. This is because `argparse`,
the Python argument parser, does not allow options to be the deciding argument for a subparser, only positional arguments. Choosing
to run the program in the way I have allows the help page to be much cleaner and more concise per option you are choosing. I believe
that this quality-of-life increase is worth the small deviation from the problem set requirements.

## Encryption Workflow
1. Generate a symmetric key and an Initialization Vector using `os.urandom`
2. Symmetrically encrypt the input data with the symmetric key and the IV
3. Asymmetrically encrypt the symmetric key with the destination's public key
4. Place (symmetric key, IV, ciphertext, tag) into a JSON table and encode as binary
5. Write to the output file

## Decryption Workflow
1. Decode the input data to JSON from binary
2. Asymmetrically decrypt the symmetric key using the private key
3. Symmetrically decrypt the ciphertext with the symmetric key and the Initialization Vector 
4. Write to the output file

## Algorithmic Decisions
When symmetrically encrypting an input, I chose to use AES in Galois Counter Mode with an Initialization Vector size of 16 bytes.
I chose to use GCM as it provides me a relatively simple authenticated encryption method with hashing for my plaintext. I chose 16
bytes as my IV size as this is greater than the NIST-recommended minimum of 12 bytes for IV size. 

For the symmetric encryption algorithm, I chose to use AES as it is a standardized and widely available encryption algorithm. It
is currently resistant againts known attacks and has CPU-level support in many implementations. This increases speed relative to
other symmetric encryption algorithms.

For the symmetric key, I chose to use a key length of 32 bytes. This is the maximum key size supported by AES, allowing the maximum
amount of rounds of encryption.

For asymmetric encryption, I chose to employ RSA. I chose this as, again, it is widely used and supports a wide range of keys and 
encoding schemes. Within RSA, I support the PEM and DER public/private key types 