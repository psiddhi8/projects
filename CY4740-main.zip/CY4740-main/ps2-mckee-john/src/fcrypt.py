import argparse
import os
from cryptography.hazmat.primitives.asymmetric import padding, types
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature, InvalidKey
import json

# A base class for our encryption/decryption.
# Handles shared tasks such as reading/writing files.
class CryptoBase:
    _private_key: types.PrivateKeyTypes  # The stored private key.
    _public_key: types.PublicKeyTypes  # The stored public key.
    input_data: bytes  # The stored input data.
    output_file: str  # The path of the output file.

    def __init__(self, private_key_path: bytes, public_key_path: str, input_data_path: str, output_file: str) -> None:
        try:
            self._private_key = self._read_private_key(private_key_path)
        except Exception as e:  # Catches various exceptions, such as invalid file paths or invalid file extensions.
            print("Error reading private key.")
            exit(1)

        try:
            self._public_key = self._read_public_key(public_key_path)
        except Exception as e:  # Catches various exceptions, such as invalid file paths or invalid file extensions.
            print("Error reading public key.")
            exit(1)

        try:
            self.input_data = self._read_file(input_data_path)
        except Exception as e:  # Catches various exceptions, such as invalid file paths or invalid file extensions.
            print("Error reading input file.")
            exit(1)
        
        self.output_file = output_file

    # Reads a file as binary data.
    def _read_file(self, filename: str) -> bytes:
        with open(filename, 'rb') as f:
            return f.read()
        
    # Writes binary data to a file.
    def _write_file(self, filename: str, data: bytes) -> None:
        with open(filename, 'wb') as f:
            f.write(data)
        
    # Attempts to read a private key from a file.
    def _read_private_key(self, private_key_path: str) -> types.PrivateKeyTypes:
        with open(private_key_path, 'rb') as f:
            if private_key_path.endswith(".pem"):
                return serialization.load_pem_private_key(
                    f.read(), 
                    password=None, 
                    backend=default_backend())
            elif private_key_path.endswith(".der"):
                return serialization.load_der_private_key(
                    f.read(), 
                    password=None, 
                    backend=default_backend())
            else:
                raise ValueError("Invalid private key file extension.")

    # Attempts to read a public key from a file.
    def _read_public_key(self, public_key_path: str) -> types.PublicKeyTypes:
        with open(public_key_path, 'rb') as f:
            if public_key_path.endswith(".pem"):
                return serialization.load_pem_public_key(
                    f.read(), 
                    backend=default_backend())
            elif public_key_path.endswith(".der"):
                return serialization.load_der_public_key(
                    f.read(), 
                    backend=default_backend())
            else:
                raise ValueError("Invalid public key file extension.")
            

# Handles the encryption of input, alongside signing.
class CryptoEncrypt(CryptoBase):
    def __init__(self, public_key: str, private_key: str, input_data: str, output_file: str) -> None:
        super().__init__(private_key, public_key, input_data, output_file)

        self._encrypt()

    # Handles the encryption of input, alongside signing.
    def _encrypt(self) -> None:
        # Generate symmetric key and IV.
        symmetric_key: bytes = os.urandom(32)
        iv: bytes = os.urandom(16)

        ciphertext, tag = self._symmetric_encrypt(symmetric_key, iv)  # Encrypt input with symmetric key.
        encrypted_symmetric_key: bytes = self._asymmetric_encrypt(symmetric_key)  # Encrypt symmetric key with public key.

        # Write serialized data to output file.
        try:
            self._write_file(self.output_file, self._serialize(encrypted_symmetric_key, iv, ciphertext, tag))
        except Exception as e:
            print("Error writing output file.")
            exit(1)

        print("Encryption complete.")

    # Handles creating the symmetric encryption component of the ciphertext.
    # Returns the ciphertext and the signing/hashing tag.
    def _symmetric_encrypt(self, symmetric_key: bytes, iv: bytes) -> tuple:
        cipher: Cipher = Cipher(algorithms.AES(symmetric_key), modes.GCM(iv), backend=default_backend())
        encryptor: Cipher.encryptor = cipher.encryptor()

        ciphertext: bytes = encryptor.update(self.input_data) + encryptor.finalize()

        return (ciphertext, encryptor.tag)
    
    # Handles creating the asymmetric encryption component of the ciphertext.
    # Returns the encrypted symmetric key.
    def _asymmetric_encrypt(self, symmetric_key: bytes) -> bytes:
        encrypted_symmetric_key: bytes = self._public_key.encrypt(
            symmetric_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA512()),
                algorithm=hashes.SHA512(),
                label=None))

        return encrypted_symmetric_key

    # Handles serializing the ciphertext.
    def _serialize(self, symmetric_key: bytes, iv: bytes, ciphertext: bytes, tag: bytes) -> bytes:
        return json.dumps({
            "symmetric_key": symmetric_key.hex(),
            "iv": iv.hex(),
            "ciphertext": ciphertext.hex(),
            "tag": tag.hex()
        }).encode()

# Handles the decryption of input, alongside signature verification.
class CryptoDecrypt(CryptoBase):
    def __init__(self, private_key: str, public_key: str, input_data: str, output_file: str) -> None:
        super().__init__(private_key, public_key, input_data, output_file)

        self._decrypt()

    # Handles the decryption of input, alongside signature verification.
    def _decrypt(self) -> None:
        # Deserialize the input data.
        deserialized_data: dict = self._deserialize(self.input_data)

        # Decrypt the symmetric key with the private key.
        try:
            symmetric_key: bytes = self._asymmetric_decrypt(deserialized_data["symmetric_key"])
        except InvalidKey as e:
            print("Invalid private key.")
            exit(1)

        # Decrypt the ciphertext with the symmetric key, IV, and tag.
        try:
            plaintext: bytes = self._symmetric_decrypt(
                symmetric_key, 
                deserialized_data["iv"], 
                deserialized_data["ciphertext"], 
                deserialized_data["tag"])
        except InvalidSignature as e:
            print("Invalid signature.")
            exit(1)
        except InvalidKey as e:
            print("Invalid symmetric key for file decryption.")
            exit(1)

        # Write the decrypted data to the output file.
        try:
            self._write_file(self.output_file, plaintext)
        except Exception as e:
            print("Error writing output file.")
            exit(1)

        print("Decryption complete.")

    # Handles deserializing the ciphertext.
    def _deserialize(self, data: bytes) -> dict:
        return {k: bytes.fromhex(v) for k, v in json.loads(data.decode()).items()}
    
    # Handles decrypting the symmetric key with the private key.
    def _asymmetric_decrypt(self, encrypted_symmetric_key: bytes) -> bytes:
        return self._private_key.decrypt(
            encrypted_symmetric_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA512()),
                algorithm=hashes.SHA512(),
                label=None))
    
    # Handles decrypting the ciphertext with the symmetric key, IV, and tag.
    def _symmetric_decrypt(self, symmetric_key: bytes, iv: bytes, ciphertext: bytes, tag: bytes) -> bytes:
        cipher: Cipher = Cipher(algorithms.AES(symmetric_key), modes.GCM(iv, tag), backend=default_backend())
        decryptor: Cipher.decryptor = cipher.decryptor()

        return decryptor.update(ciphertext) + decryptor.finalize()

# The main entrypoint for our program.
def main():
    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        prog='fcrypt', 
        description='A simple file encryption/decryption program.'
    )
    # We create a subparser to handle the two modes of our program, 'encrypt' and 'decrypt'.
    subparsers: argparse._SubParsersAction = parser.add_subparsers(description="Available modes.", dest="mode")
    subparsers.required = True

    # Subparser for encryption.
    parser_encrypt: argparse.ArgumentParser = subparsers.add_parser(
        "e", 
        help="Encrypt and sign an input [e --help for more info]", 
        description="Encrypt an input, signing the resulting ciphertext with the sender's private key."
    )
    parser_encrypt.add_argument("destination_public_key_filename", type=str, help="The destination public key filename.")
    parser_encrypt.add_argument("source_private_key_filename", type=str, help="The source private key filename.")
    parser_encrypt.add_argument("input_plaintext_file", type=str, help="The input plaintext file.")
    parser_encrypt.add_argument("ciphertext_file", type=str, help="The output ciphertext file.")

    # Subparser for decryption.
    parser_decrypt: argparse.ArgumentParser = subparsers.add_parser(
        "d", 
        help="Decrypt a signed input [d --help for more info]", 
        description="Decrypt an input, confirming the sender's signature with the sender's public key."
    )
    parser_decrypt.add_argument("destination_private_key_filename", type=str, help="The destination private key filename.")
    parser_decrypt.add_argument("source_public_key_filename", type=str, help="The source public key filename.")
    parser_decrypt.add_argument("ciphertext_file", type=str, help="The input ciphertext file.")
    parser_decrypt.add_argument("output_plaintext_file", type=str, help="The output plaintext file.")

    args: argparse.Namespace = parser.parse_args()

    if args.mode == "e":
        print("Encryption mode selected.")
        CryptoEncrypt(args.destination_public_key_filename, args.source_private_key_filename, args.input_plaintext_file, args.ciphertext_file)
    elif args.mode == "d":
        print("Decryption mode selected.")
        CryptoDecrypt(args.destination_private_key_filename, args.source_public_key_filename, args.ciphertext_file, args.output_plaintext_file)

if __name__ == '__main__':
    main()