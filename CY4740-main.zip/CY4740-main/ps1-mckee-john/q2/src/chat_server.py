import argparse
import socket
import chat_logging
import logging
from select import select
import json

MAX_MSG_LEN: int = 65535  # The maximum length of a message that can be sent over the network

chat_logger: logging.Logger = chat_logging.create_logger('server')  # Creating a logger for the server

# A class that contains all relevant code for the chat server.
class ChatServer():
    _sock: socket.socket  # The socket that the server will use to communicate with clients
    _clients: list[dict[str, str]] = []  # A list of clients that are currently connected to the server

    # The constructor for the ChatServer class.
    def __init__(self, server_port: int) -> None:
        # Checking if the port number is valid. If not, exit the program with an error.
        if not 0 < server_port < 65536:
            chat_logger.critical("The port number must be between 1 and 65535.")
            print("The port number must be between 0 and 65535.")
            chat_logger.debug(f"Given port: {server_port}")
            exit(1)

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Creating a UDP socket
        self._sock.bind(('', server_port))                             # And binding it to the specified port on localhost

        print("Server initialized...")
        chat_logger.info("Server initialized...")
        chat_logger.debug(f"Server port: {server_port}")

        self._run()

    # The main loop for the ChatServer class.
    def _run(self) -> None:
        try:
            while True:
                # Wait for new data to arrive on the socket
                sock: socket.socket = select([self._sock], [], [])[0]

                # Hand off the socket to the receive function to handle the data
                self._recv()
        except KeyboardInterrupt:  # This handles if the user presses CTRL/CMD+C to exit the program.
            chat_logger.debug("Received KeyboardInterrupt.")
            chat_logger.info("Server shutting down...")
            print("\nServer shutting down...")

    # Fetches the username of a client based on their IP address and port.
    def _get_username(self, ip: str, port: int) -> str:
        return [client['username'] for client in self._clients if client['ip'] == ip and client['port'] == port][0]

    # A function that handles receiving data from the socket.
    def _recv(self) -> None:
        json_bytes, addr = self._sock.recvfrom(MAX_MSG_LEN)
        chat_logger.info(f"Received message from {addr[0]}:{addr[1]}")

        # Decodes and deserializes the JSON data
        json_str: str = json_bytes.decode('utf-8')
        msg_table: dict = json.loads(json_str)

        msg_type: str = msg_table['type']

        chat_logger.debug(f"Message type: {msg_type}")

        if msg_type == 'SIGN-IN':
            self._sign_in(addr[0], addr[1], msg_table['username'])
        elif msg_type == 'LIST':
            self._list(addr[0], addr[1])
        elif msg_type == 'LOOKUP':
            self._lookup(addr[0], addr[1], msg_table['username'])
        elif msg_type == 'SIGN-OUT':
            self._sign_out(addr[0], addr[1])
        else:
            chat_logger.warning(f"Received message with invalid type: {msg_type}")


    # A function that handles serializing and sending data to the socket.
    def _send_table(self, msg_table: dict, ip: str, port: int):
        json_str: str = json.dumps(msg_table)
        json_bytes: bytes = json_str.encode('utf-8')

        self._sock.sendto(json_bytes, (ip, port))

    # Handles the client's initial 'sign-in' message to the server.
    def _sign_in(self, ip: str, port: int, username: str) -> None:
        if any(client['ip'] == ip and client['port'] == port for client in self._clients):
            chat_logger.warning(f"Client {username} is already signed in.")
            # This is done in case the user tries to sign in after a hard bail but they want a different username. If we didn't do this, they'd be stuck with the same username.
            chat_logger.debug(f"Signing user out for sanitized sign-in")  
            self._sign_out(ip, port) 
        
        # Add the client to the list of online clients.
        self._clients.append({
            'ip': ip,
            'port': port,
            'username': username
        })

        chat_logger.info(f"Client {username} signed in.")

    # Handles the client's 'list' request to the server.
    def _list(self, ip: str, port: int) -> None:
        client_list: list[str] = [client['username'] for client in self._clients if client['ip'] != ip or client['port'] != port]

        # Constructs the reply using the list of clients
        msg_table: dict = {
            'type': 'LIST',
            'clients': client_list
        }

        self._send_table(msg_table, ip, port)

        chat_logger.info(f"Sent list of clients to {[client['username'] for client in self._clients if client['ip'] == ip and client['port'] == port][0]}")

    # Handles the client's 'lookup' request of a specific client to the server.
    def _lookup(self, ip: str, port: int, username: str) -> None:
        client: dict[str, str] = [client for client in self._clients if client['username'] == username]
        
        # If the client doesn't exist, send an empty reply
        if len(client) == 0:
            chat_logger.info(f"Client {username} not found.")
            client = {"ip": "", "port": ""}
        else:
            client = client[0]

        # Constructs the reply using the client's IP address and port
        msg_table: dict = {
            'type': 'LOOKUP',
            'ip': client['ip'],
            'port': client['port']
        }

        self._send_table(msg_table, ip, port)

        chat_logger.info(f"Sent lookup of {username} to {self._get_username(ip, port)}")

    # Handles the client's graceful 'sign-out' message to the server.
    # The server won't always receive this, so we should check with the client to see if they're still online when looked up.
    def _sign_out(self, ip: str, port: int) -> None:
        if not any(client['ip'] == ip and client['port'] == port for client in self._clients):
            chat_logger.warning(f"Client at {ip}:{port} is not signed in.")
            return

        self._clients.remove([client for client in self._clients if client['ip'] == ip and client['port'] == port][0])

        chat_logger.info("Signed out client.")


# The entrance point for the code.
def main():
    # Creating a parser for the command line arguments
    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        prog='chat_server',
        description='A server responsible for coordinating chat messages between clients.'
    )
    parser.add_argument("-sp", type = int, help = "The port the server will run on", dest = "server_port", required = True)
    args: argparse.Namespace = parser.parse_args()

    ChatServer(args.server_port)

if __name__ == '__main__':
    main()