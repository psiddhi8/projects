import chat_logging
import logging
import argparse
import socket
import sys
from select import select
import json

MAX_MSG_LEN: int = 65535 # The maximum length of a message that can be sent over the network

chat_logger: logging.Logger = chat_logging.create_logger('client')  # Creating a logger for the client

class ChatClient():
    _sock: socket.socket  # The socket that the client will use to communicate with the server and others.
    _cached_message: str  # A cached message that will be sent to the server when the client receives the IP and port of the recipient
    _username: str        # The username of the client
    _server_ip: str       # The IP address of the server
    _server_port: int     # The port the server is running on

    # The constructor for the ChatClient class.
    def __init__(self, username: str, server_ip: str, server_port: int) -> None:
        # Checking if the port number is valid. If not, exit the program with an error.
        if not 0 <= server_port < 65536:
            chat_logger.critical("The port number must be between 0 and 65535.")
            print("The port number must be between 0 and 65535.")
            chat_logger.debug(f"Given port: {server_port}")
            exit(1)

        # Save server information for future reference.
        self._username = username
        self._server_ip = server_ip
        self._server_port = server_port

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Creating a UDP socket
        self._sock.bind(('', 0))                                       # And allowing the OS to choose a port for us on localhost

        chat_logger.info("Client initialized...")
        chat_logger.debug(f"Client username: {username}")
        chat_logger.debug(f"Server IP: {server_ip}")
        chat_logger.debug(f"Server port: {server_port}")
        chat_logger.debug(f"Client port: {self._sock.getsockname()[1]}")

        self._sign_in()
        print("+> ", end="", flush=True)
        self._run()

    # The main loop for the ChatClient class.
    def _run(self):
        try:
            while True:
                input_sources: list = [self._sock, sys.stdin]
                socks: list = select(input_sources, [], [])[0]  # Wait for new data to arrive on the socket or stdin

                for sock in socks:
                    if sock == self._sock:  # If the socket has new data, receive it
                        self._recv(self._sock)
                    elif sock == sys.stdin:  # If stdin has new data, send it
                        self._send(sock.readline().rstrip())

        except KeyboardInterrupt:  # This handles if the user presses CTRL/CMD+C to exit the program.
            self._sign_out()  # Tell the server we are no longer online
            chat_logger.debug("Received KeyboardInterrupt.")
            chat_logger.info("Client shutting down...")
            print("\nClient shutting down...")

    # Manages any data received from the socket
    def _recv(self, sock: socket.socket):
        json_bytes, addr = self._sock.recvfrom(MAX_MSG_LEN)
        chat_logger.info(f"Received message from {addr[0]}:[{addr[1]}")

        # Decodes and deserializes the JSON data
        json_str: str = json_bytes.decode('utf-8')
        msg_table: dict = json.loads(json_str)

        msg_type: str = msg_table['type']

        chat_logger.debug(f"Message type: {msg_type}")

        # Clear the current line
        print(f"\r{' ' * 50}\r", end="", flush=True)

        if msg_type == "LIST":
            self._print_list(msg_table["clients"])
        elif msg_type == "LOOKUP":
            self._send_message(msg_table["ip"], msg_table["port"])
        elif msg_type == "MESSAGE":
            self._print_message(addr[0], addr[1], msg_table["username"], msg_table["message"])
        else:
            chat_logger.warning(f"Received message with invalid type: {msg_type}")

        # Print the prompt again, after any other function has had it's opportunity to print.
        print(f"+> ", end="", flush=True)

    # Manages any data received from stdin
    def _send(self, msg: str):
        msg_split: list = msg.split()
        
        if len(msg_split) > 0:  # If the user entered something
            keyword: str = msg_split[0].upper()

            if keyword == "LIST":  # If the user wants to list all signed in users
                self._request_list()
            elif keyword == "SEND":  # If the user wants to send a message to another user
                if len(msg_split) > 2:  # Check that they entered a username and a message
                    self._cached_message = " ".join(msg_split[2:])
                    
                    self._request_lookup(msg_split[1])
                else:
                    print("Invalid number of arguments.")
            else:
                print("Invalid command.")

        print("+> ", end="", flush=True)

    # Handles serializing and sending data to the socket.
    def _send_table(self, msg_table: dict, ip: str, port: int):
        json_str: str = json.dumps(msg_table)
        json_bytes: bytes = json_str.encode('utf-8')

        self._sock.sendto(json_bytes, (ip, port))

    # Handles the client's initial 'sign-in' message to the server.
    def _sign_in(self):
        msg_table: dict = {
            "type": "SIGN-IN",
            "username": self._username
        }

        self._send_table(msg_table, self._server_ip, self._server_port)

    # Prints the received list of signed in users.
    def _print_list(self, clients: list):
        print(f"<- Signed In Users: {", ".join(clients)}")

    # Sends a message to the specified user.
    def _send_message(self, ip: str, port: int):
        # This reply can be empty, so we must check first.
        if ip == "" or port == 0:
            print("<- User not found.")
            return

        msg_table: dict = {
            "type": "MESSAGE",
            "username": self._username,
            "message": self._cached_message
        }

        self._send_table(msg_table, ip, port)

    # Prints a message received from another user.
    def _print_message(self, ip: str, port: int, username: str, message: str):
        print(f"<- <From {ip}:{port}:{username}> {message}")

    # Requests a list of all other signed in users from the server.
    def _request_list(self):
        msg_table: dict = {
            "type": "LIST"
        }

        self._send_table(msg_table, self._server_ip, self._server_port)

    # Requests the IP and port of a specific user from the server.
    def _request_lookup(self, username: str):
        msg_table: dict = {
            "type": "LOOKUP",
            "username": username
        }

        self._send_table(msg_table, self._server_ip, self._server_port)

    # Tells the server that the client is no longer online.
    def _sign_out(self):
        msg_table: dict = {
            "type": "SIGN-OUT"
        }

        self._send_table(msg_table, self._server_ip, self._server_port)

# The entrance point for the code.
def main():
    # Creating a parser for the command line arguments
    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        prog='chat_client',
        description='A simple chat client that allows logged in members to send eachother messages.'
    )
    parser.add_argument("-u", type = str, help = "The username of the client", dest = "username", required = True)
    parser.add_argument("-sip", type = str, help = "The IP address of the server", dest = "server_ip", required = True)
    parser.add_argument("-sp", type = int, help = "The port the server is running on", dest = "server_port", required = True)
    args: argparse.Namespace = parser.parse_args()

    ChatClient(args.username, args.server_ip, args.server_port)

if __name__ == '__main__':
    main()