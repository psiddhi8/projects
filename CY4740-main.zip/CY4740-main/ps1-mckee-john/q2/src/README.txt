# Chat Client

For this project, my main concern was to make the system as stateless as I could. Less states meant less variables to track which decreases points of failure. 
To implement this, I leveraged the messaging system between the server and clients to keep variables in transit. One example of this was the system of sending 
the IP-Port pair to the client to allow them to DM other clients. Instead of keeping an open connection between the client and server, I cache the message and 
send a "lookup" message to the server. The server then sends back the result of the lookup on the username. Once my client receives this message, it fetches 
the cached message and sends it to the received IP and port. By doing this, the only thing I had to store was the user's message.

Due to time constraints, I decided to make certain design decisions about my client-server interaction. One example is that a client can message themselves. 
If I had more time I would have added checks to disallow this but I determined that this was "harmless" enough to allow in. 

Another change I would like to incorporate would be a "heartbeat" system for client-server connections. This system would allow the server to automatically 
prune client lists of crashed clients by sending out heartbeat messages and removing clients if they didn't reply within a certain time.