import socket
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization, hashes, hmac
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
import os
import logging
from cryptography.exceptions import InvalidSignature

secure_logger: logging.Logger

class SecureBase:
    _sock: socket  # The socket that the server will use to communicate with clients
    _p: int

    # This function is used to load the modulus p from a file.
    def _load_p(self, file_path: str) -> int:
        with open(file_path, "r") as f:
            p_hex: str = f.read().replace(' ', '').replace('\n', '').strip()
            return int(p_hex, 16)

    # This function encrypts a message using an RSA public key and computes an HMAC for it.
    def _symm_key_enc(self, msg: bytes, key: int) -> tuple:
        # Step 1: Derive AES and HMAC Keys
        (aes_key, hmac_key) = self._derive_keys(key)
        iv = os.urandom(12)
        
        # Step 2: Encrypt the message
        cipher = Cipher(algorithms.AES(aes_key), modes.GCM(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted_message = encryptor.update(msg) + encryptor.finalize()
        tag = encryptor.tag

        # Step 3: Compute HMAC
        h = hmac.HMAC(hmac_key, hashes.SHA256(), backend=default_backend())
        h.update(encrypted_message)
        message_mac = h.finalize()

        return (message_mac, iv, tag, encrypted_message)
    
    # This function reads a message and returns the MAC, IV, tag, and encrypted data.
    def _symm_data_format(self, data: bytes) -> tuple:
        mac = data[:32]
        iv = data[32:44]
        tag = data[44:60]
        encrypted_data = data[60:] 

        return (mac, iv, tag, encrypted_data)
    
    # This function decrypts a message using an RSA private key and verifies the HMAC.
    def _symm_key_dec(self, ciphertext: bytes, mac: bytes, iv: bytes, tag: bytes, key: int) -> bytes:
        (aes_key, hmac_key) = self._derive_keys(key)

        # Decrypt the message
        cipher = Cipher(algorithms.AES(aes_key), modes.GCM(iv, tag))
        decryptor = cipher.decryptor()
        decrypted_message: bytes = None
        try:
            decrypted_message = decryptor.update(ciphertext) + decryptor.finalize()
        except Exception as e:
            secure_logger.error(f"Decryption failed or integrity check failed: {e}")
            

        # Verify HMAC for additional integrity check
        h = hmac.HMAC(hmac_key, hashes.SHA256(), backend=default_backend())
        h.update(ciphertext)  # Note: HMAC is computed on the encrypted message
        try:
            h.verify(mac)
            return decrypted_message
        except InvalidSignature:
            secure_logger.error("HMAC verification failed.")

    # This function reads a key from a file and returns the key object.
    def read_key(self, filename: str, key_type: str) -> None:
        try:
            with open(filename, 'rb') as key_file:
                key_data = key_file.read()

                if key_type == 'private':
                    if filename.lower().endswith(".pem"):
                        return serialization.load_pem_private_key(key_data, password=None)
                    elif filename.lower().endswith(".der"):
                        return serialization.load_der_private_key(key_data, password=None)
                    else:
                        raise ValueError("Unsupported private key file extension. Use '.pem' or '.der'.")
                else:
                    if filename.lower().endswith(".pem"):
                        return serialization.load_pem_public_key(key_data)
                    elif filename.lower().endswith(".der"):
                        return serialization.load_der_public_key(key_data)
                    else:
                        raise ValueError("Unsupported public key file extension. Use '.pem' or '.der'.")
        except Exception as e:
            raise Exception(f"Error reading {key_type} key file: {e}")
        
    # This function derives AES and HMAC keys from the original key.
    def _derive_keys(self, original_key: int) -> tuple:
        key = int.to_bytes(original_key, 256)  # Convert to bytes
        kdf = HKDF(
            algorithm=hashes.SHA256(),
            length=64,  # 32 bytes for AES, 32 bytes for HMAC
            salt=None,
            info=b'encryption and hmac',
            backend=default_backend()
        )
        derived_keys = kdf.derive(key)
        aes_key = derived_keys[:32]
        hmac_key = derived_keys[32:]
        return (aes_key, hmac_key)