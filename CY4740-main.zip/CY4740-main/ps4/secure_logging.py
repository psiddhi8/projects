import logging
import os

# A helper function that creates 2 sources for logging
# All data is output to the named file, while only warnings and errors are output to the user console
def create_logger(log_file_suffix: str) -> logging.Logger:
    logger: logging.Logger = logging.getLogger('secure')
    logger.setLevel(logging.DEBUG)
    
    stream_handler: logging.StreamHandler = logging.StreamHandler()
    stream_handler.setLevel(logging.WARNING)

    path: str = os.path.join(os.path.dirname(__file__), 'logs', f"secure_{log_file_suffix}.log")

    file_handler: logging.FileHandler = logging.FileHandler(path)

    formatter: logging.Formatter = logging.Formatter('%(asctime)s [%(levelname)s]: %(message)s')

    stream_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    logger.addHandler(stream_handler)
    logger.addHandler(file_handler)

    return logger