from secure_base import SecureBase
import secure_logging
import os
import logging
import socket
from select import select
import sys, json
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.asymmetric import types as asym_types
from cryptography.exceptions import InvalidSignature
import time

MAX_MSG_LEN: int = 65535
G: int = 2
MAX_TIMESTAMP_DELTA: int = 10

secure_logger = secure_logging.create_logger('client')

class SecureClient(SecureBase):
    _sock: socket.socket
    _server_sock: socket.socket
    _username: str
    _password: str
    _server_pub_key: asym_types.PublicKeyTypes
    _server_symm_key: int
    _server_ip: str
    _server_port: int
    _c2: bytes
    _peers: dict = {}
    _input_sources: list = []

    def __init__(self, user: str, pw: str, ip: str, port: int) -> None:
        if not 0 <= port < 65536:
            secure_logger.critical("The port number must be between 0 and 65535.")
            print("The port number must be between 0 and 65535.")
            secure_logger.debug(f"Given port: {port}")
            exit(1)
        
        self._username = user
        self._password = pw
        self._server_symm_key = None
        self._p = self._load_p("p.txt")
        try:
            self._server_pub_key = self.read_key("server_public_key.pem", "public")
        except Exception as e:
            secure_logger.critical("Could not read the server's public key.")
            exit(1)
        self._server_ip = ip
        self._server_port = port
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Creating a TCP listening socket
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(('', 0))
        self._sock.listen()
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Create server socket
        try:
            self._server_sock.connect((ip, port))  # Connect to the server
        except ConnectionRefusedError:
            secure_logger.critical("Could not connect to the server.")
            exit(1)
        self._input_sources: list = [self._sock, sys.stdin, self._server_sock]

        secure_logger.info("Client initialized...")
        secure_logger.debug(f"Server IP: {ip}")
        secure_logger.debug(f"Server port: {port}")

        self._start()
        self._run()

    _a: int

    def _start(self) -> None:
        self._a = int.from_bytes(os.urandom(128))
        g_a: int = pow(G, self._a, self._p)

        ga_bytes: bytes = int.to_bytes(g_a, 256)
        user_bytes: bytes = self._username.encode()
        message_bytes: bytes = [ga_bytes, user_bytes]
        message_bytes = b''.join(message_bytes)
        
        encrypted_data: bytes = self._server_pub_key.encrypt(
            message_bytes,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        secure_logger.info(f"Sending initial handshake message to server.")
        self._server_sock.send(encrypted_data)

    def _run(self) -> None:
        try:
            while True:
                self._input_sources = [sock for sock in self._input_sources if sock.fileno() != -1]
                socks: list = select(self._input_sources, [], [])[0]  # Wait for new data to arrive on the socket or stdin

                for sock in socks:
                    if sock == self._sock:  # If the socket is a new connection
                        client_sock, addr = self._sock.accept()
                        try:
                            secure_logger.info("New connection received.")
                            secure_logger.debug(f"IP: {addr[0]}, Port: {addr[1]}")
                            self._new_connection(client_sock)
                        except Exception as e:
                            client_sock.close()
                    elif sock == sys.stdin:  # If stdin has new data
                        self._handle_stdin(sock.readline().rstrip())
                    elif sock == self._server_sock:  # If the server socket has new data 
                        self._recv_server(sock)
                    else:   # If the connected client sockets have new data
                        self._recv_client(sock)
        except KeyboardInterrupt:  # This handles if the user presses CTRL/CMD+C to exit the program.
            self._sign_out()  
            secure_logger.debug("Received KeyboardInterrupt.")
            secure_logger.info("Client shutting down...")
            print(f"\n{self._username} logging out.")

    def _new_connection(self, sock: socket.socket) -> None:
        data = sock.recv(MAX_MSG_LEN)
        if len(data) == 0:
            return

        secure_logger.debug(f"Received data: {data}")
        msg_table: dict = json.loads(data.decode())

        if msg_table["type"] != "CONNECT":
            secure_logger.error("Invalid initial message type received.")
            raise Exception("Invalid initial message type received.")

        ticket: bytes = int.to_bytes(msg_table["ticket"], msg_table["ticket_len"])
        (mac, iv, tag, encrypted_data) = self._symm_data_format(ticket)
        ticket_tbl: dict = json.loads(self._symm_key_dec(encrypted_data, mac, iv, tag, self._server_symm_key).decode())
        #secure_logger.debug(f"Ticket: {ticket_tbl}")
    
        #check user sending message is the same as the user in the ticket
        if msg_table["username"] != ticket_tbl["username"]:
            secure_logger.error("Username in ticket does not match username in message.")
            raise Exception("Username in ticket does not match username in message.")

        self._peers[msg_table["username"]] = {
            "ip": sock.getpeername()[0],
            "port": sock.getpeername()[1],
            "socket": sock,
        }

        self._input_sources.append(sock)

        #decrypt nonce
        nonce: bytes = int.to_bytes(msg_table["nonce"], 68)
        (mac, iv, tag, encrypted_data) = self._symm_data_format(nonce)
        n_2 = self._symm_key_dec(encrypted_data, mac, iv, tag, ticket_tbl["shared_key"])
        n_2_minus_1 = int.from_bytes(n_2) - 1
        n_3: int = int.from_bytes(os.urandom(8))
        
        # set peer symmetric key info
        self._peers[msg_table["username"]]["symm_key"] = {
            "key": ticket_tbl["shared_key"],
            "nonce": n_3, 
            "verified": False
        }
        
        msg_table: dict = {
            "type": "VERIFICATION_RESPONSE_AND_REQUEST",
            "n_2_minus_1": n_2_minus_1,
            "n_3": n_3
        }
        
        # secure_logger.info(f"Sending verification response to {msg_table['username']}")
        secure_logger.debug(f"N2 - 1: {n_2_minus_1}, N3: {n_3}")
        
        self._send(sock, msg_table, ticket_tbl["shared_key"])

    def _recv_server(self, sock: socket.socket) -> None:
        data: bytes = sock.recv(MAX_MSG_LEN)
        if len(data) == 0:
            return

        if self._server_symm_key is None:
            if data[:5] == b"ERROR":
                secure_logger.error("Server error: Invalid username or password.")
                exit(1)

            secure_logger.info("Generating shared key with server.")
            self._generate_shared_key(data)
        elif self._c2 is not None:
            if data[:5] == b"ERROR":
                secure_logger.error("Server error: Invalid username or password.")
                exit(1)

            secure_logger.info("Verifying C2 received from server.")
            self._verify_c2(data)
        else:
            self._server_message_handler(data)

    def _recv_client(self, sock: socket.socket) -> None:
        data = sock.recv(MAX_MSG_LEN)
        if len(data) == 0:
            return

        #when we recieve from clients, we need to check if user is verified
        user, info = [(user, user_data) for user, user_data in self._peers.items() if user_data["socket"] is not None and user_data["socket"] == sock][0]
        
        connection_is_verified: bool = info["symm_key"]["verified"]
        if connection_is_verified:
            secure_logger.info(f"Handling incoming message from {user}.")
            self._client_message_handler(data, user, info)
        else:
            secure_logger.info(f"Verifying {user} to connect with {self._username}.")
            
            try:
                self._verify_client(data, user, info)
                secure_logger.info(f"Successfully verified {user}.")
            except Exception as e:
                secure_logger.error(f"Error: {e}")
                secure_logger.debug(f"Verification failed for {user}.")
                secure_logger.debug(f"Message: {data}")
                secure_logger.debug(f"User: {user}")
                secure_logger.debug(f"Info: {info}")

    # This function established the shared key b/t the client and the server using the Diffie-Hellman key exchange.
    def _generate_shared_key(self, data: bytes) -> None:
        g_b: int = int.from_bytes(data[:256])
        u: int = int.from_bytes(data[256:260])
        c_1: int = data[260:268]
        signature: bytes = data[268:]
        
        #Verify the signature
        try:
            self._server_pub_key.verify(
                signature,
                data[:268],
                asym_padding.PSS(
                    mgf=asym_padding.MGF1(hashes.SHA256()),
                    salt_length=asym_padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
        except InvalidSignature:
            secure_logger.error("Invalid Server Signature")
            raise Exception("Invalid Signature")
        
        #Calculate the shared secret
        W = int.from_bytes(self._password.encode())
        self._server_symm_key = pow(g_b, self._a + u*W, self._p)

        #Sending message
        (mac, iv, tag, encrypted_list) = self._symm_key_enc(c_1, self._server_symm_key)
        self._c2: bytes = os.urandom(8) # 8 bytes

        secure_logger.info("Sending encrypted C1 and plaintext C2 to server.")
        self._server_sock.send(mac+iv+tag+encrypted_list+self._c2)

    # This function mutually authenticates the server by verifying the C2.
    def _verify_c2(self, data: bytes) -> None:    
        (mac, iv, tag, encrypted_c2) = self._symm_data_format(data)
        c_2 = self._symm_key_dec(encrypted_c2, mac, iv, tag, self._server_symm_key)

        if c_2 == self._c2:
            print("You have successfully logged in!")
            self._c2 = None
            _, port = self._sock.getsockname()
            msg_table: dict = {
                "type": "PORT",
                "port": port
            }
            secure_logger.info("Sending listening port to server.")
            secure_logger.debug(f"Port: {port}")
            self._send(self._server_sock, msg_table, self._server_symm_key)
        else:
            secure_logger.critical("C2 verification failed.")
            print("Unable to verify connection integrity with server. Exiting...")
            exit(1)

    # This function handles information sent to client from server.
    def _server_message_handler(self, data: bytes) -> None:
        (mac, iv, tag, encrypted_data) = self._symm_data_format(data)
        message: dict = json.loads(self._symm_key_dec(encrypted_data, mac, iv, tag, self._server_symm_key).decode())

        if message["type"] == "LIST":
            secure_logger.info("Received list of users from server.")
            users_string = ', '.join(message['users'])
            print(f"Online Users: {users_string}")
            print("+> ", end="", flush=True)
        elif message["type"] == "ERROR":
            secure_logger.warning(f"Received error message from server: {message['error']}")
            if message["error"] == "User not found":
                self._peers.pop(message["peer"], None)
            print(f"Server Error: {message['error']}")
            print("+> ", end="", flush=True)
        elif message["type"] == "SHARED KEY":  
            secure_logger.info(f"Received shared key from server for {message['username']}")
            try:
                self._send_shared_key(message)
                secure_logger.info(f"Shared key sent to {message['username']}")
            except Exception as e:
                secure_logger.error(f"Error occured as {e}.")
                secure_logger.debug(f"Unable to send shared key to {message['username']}.")
        else:
            # possible "SERVER stopped"
            # print exit message for user or something
            pass

    # This function prints a message sent to the client by a peer.
    def _client_message_handler(self, data: bytes, user: str, peer: dict) -> None:
        (mac, iv, tag, encrypted_data) = self._symm_data_format(data)
        message: dict = json.loads(self._symm_key_dec(encrypted_data, mac, iv, tag, peer["symm_key"]["key"]).decode())

        if message["type"] == "MESSAGE":
            if abs(time.time() - message["timestamp"]) > MAX_TIMESTAMP_DELTA:
                secure_logger.error(f"Received message from {user} with invalid timestamp.")
                secure_logger.debug(f"Message: {message['message']}")
                secure_logger.debug(f"Timestamp delta: {abs(time.time() - message['timestamp'])}")
                print("+> ", end="", flush=True)
                return
            else:
                print(f"{user}: {message['message']}")
                print("+> ", end="", flush=True)
        elif message["type"] == "SIGN-OUT":
            secure_logger.info(f"\n{user} has signed out.")
            self._input_sources.remove(self._peers[user]["socket"])
            self._peers[user]["socket"].close()
            self._peers.pop(user, None)
            print(f"{user} has signed out.")
            print("+> ", end="", flush=True)
    
    # This function verifies the client's shared key with a peer.
    def _verify_client(self, data: bytes, user: str, peer: dict) -> None:
        (mac, iv, tag, encrypted_data) = self._symm_data_format(data)
        message: dict = json.loads(self._symm_key_dec(encrypted_data, mac, iv, tag, peer["symm_key"]["key"]).decode())

        nonce = peer["symm_key"]["nonce"]
        if message["type"] == "VERIFICATION_RESPONSE_AND_REQUEST":
            # Check if the nonce is correct
            if message["n_2_minus_1"] == nonce - 1:
                self._peers[user]["symm_key"]["verified"] = True
                secure_logger.info(f"Successfully verified shared key with {user}.")
                msg_dict: dict = {
                    "type": "VERIFICATION_RESPONSE",
                    "n_3_minus_1": message["n_3"] - 1
                }
                self._send(peer["socket"], msg_dict, peer["symm_key"]["key"])
                time.sleep(0.5)
                self._send_message(peer, peer["cached_message"])
                secure_logger.info(f"Sent cached message to {user}.")
                #_logger.debug(f"Message: {peer['cached_message']}")
                print("+> ", end="", flush=True)
            else:
                raise Exception("Nonce verification failed")
        elif message["type"] == "VERIFICATION_RESPONSE":    
            if message["n_3_minus_1"] == nonce - 1:
                self._peers[user]["symm_key"]["verified"] = True
                secure_logger.info(f"Successfully verified shared key with {user}.")
            else:
                raise Exception("Nonce verification failed")
        else:
            raise Exception("Invalid message type")

    # This function processes user input from stdin
    def _handle_stdin(self, input: str) -> None:
        msg_split: list = input.split()
        if len(msg_split) > 0:  # If the user entered something
            keyword: str = msg_split[0].upper() # Get the first word of the input
            # If the user wants to list all signed in users
            if keyword == "LIST":  
                self._request_list()
            # If the user wants to send a message to another user    
            elif keyword == "SEND": 
                # Check that they entered a username and a message
                if len(msg_split) > 2:  
                    # Save the message to send while we get the shared key
                    # Check if the user is already in the peers dictionary
                    if self._peers.get(msg_split[1]) is not None:
                        if self._peers[msg_split[1]]["symm_key"]["verified"]: # If the shared key is verified
                            self._send_message(self._peers[msg_split[1]], " ".join(msg_split[2:]))
                    elif msg_split[1] == self._username:
                        print("You cannot send a message to yourself.")
                    else: # Request the shared key from the server
                        secure_logger.info(f"Requesting shared key from server for {msg_split[1]}.")      
                        self._peers[msg_split[1]] = {"symm_key": {}, "ip": None, "port": None, "cached_message": " ".join(msg_split[2:])}  
                        self._request_shared_key(msg_split[1])
                else:
                    print("Invalid number of arguments.")
            else:
                print("Invalid command.")

        print("+> ", end="", flush=True)

    # This function requests a shared key from the server.
    def _request_shared_key(self, username: str) -> None:
        self._peers[username]["server_nonce"] = int.from_bytes(os.urandom(8))
        msg_table: dict = {
            "type": "SHARED KEY",
            "my_name": self._username,
            "peer": username,
            "nonce": self._peers[username]["server_nonce"]}
        self._send(self._server_sock, msg_table, self._server_symm_key)

    # This function requests a list of logged in users from the server. 
    def _request_list(self):
        msg_table: dict = {
            "type": "LIST"}
        self._send(self._server_sock, msg_table, self._server_symm_key)

    # This function starts Needham Schroeder authentication with a client after receving a shared key from the server.
    def _send_shared_key(self, message: dict) -> None:
        if message["nonce"] != self._peers[message["username"]]["server_nonce"]:
            secure_logger.error("Identity challenge mismatch with server. Unable to send shared key.")
            return
        
        nonce: bytes = os.urandom(8)
        self._peers[message["username"]]["symm_key"] = {
            "key": message["shared_key"],
            "nonce": int.from_bytes(nonce), 
            "verified": False
        }
        self._peers[message["username"]]["ip"] = message["ip"]
        self._peers[message["username"]]["port"] = message["port"]
        
        (mac, iv, tag, encrypted_data) = self._symm_key_enc(nonce, message["shared_key"])
        msg_tbl: dict = {
            "type": "CONNECT",
            "username": self._username,
            "ticket": message["TTB"],
            "ticket_len": message["ttb_len"],
            "nonce": int.from_bytes(mac+iv+tag+encrypted_data)
        }
        secure_logger.info(f"Sending connection message to {message['username']}")
        secure_logger.debug(f"IP: {message['ip']}, Port: {message['port']}")
        self._peers[message["username"]]["socket"] = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._peers[message["username"]]["socket"].connect((message["ip"], message["port"]))
        self._peers[message["username"]]["socket"].send(json.dumps(msg_tbl).encode())
        self._input_sources.append(self._peers[message["username"]]["socket"])
        
    # This function sends a message to the given socket, encrypted with the appropriate shared key.
    def _send(self, sock: socket.socket, msg_table: dict, key: bytes) -> None:
        msg_table = json.dumps(msg_table).encode()
        (mac, iv, tag, encrypted_list) = self._symm_key_enc(msg_table, key)
        sock.send(mac+iv+tag+encrypted_list)

    # This function sends a message to the given peer.
    def _send_message(self, peer: dict, msg: str) -> None:
        msg_table: dict = {
            "type": "MESSAGE",
            "message": msg,
            "timestamp": time.time(),
        }
        self._send(peer["socket"], msg_table, peer["symm_key"]["key"])

    # This function sends a sign out message to the server.
    def _sign_out(self):
        msg_table: dict = {
            "type": "SIGN-OUT"
        }
        self._send(self._server_sock, msg_table, self._server_symm_key)
        self._server_sock.close()
        for name, info in self._peers.items():
            self._send(info["socket"], msg_table, info["symm_key"]["key"])
            info["socket"].close()

def main():
    # # Creating a parser for the command line arguments
    # parser: argparse.ArgumentParser = argparse.ArgumentParser(
    #     prog='secure_chat_client',
    #     description='A chat client that allows logged in members to securely send each others messages.'
    # )
    # parser.add_argument("-u", type = str, help = "The username of the client", dest = "username", required = True)
    # parser.add_argument("-p", type = str, help = "The password of the client", dest = "password", required = True)
    # parser.add_argument("-sip", type = str, help = "The IP address of the server", dest = "server_ip", required = True)
    # parser.add_argument("-sp", type = int, help = "The port the server is running on", dest = "server_port", required = True)
    # args: argparse.Namespace = parser.parse_args()
    
    # SecureClient(args.username, args.password, args.server_ip, args.server_port)
    ip, port = read_server_conf("server.conf")
    
    username = input("Enter username: ")
    password = input("Enter password: ")

    SecureClient(username, password, ip, port)

def read_server_conf(path: str) -> tuple:
    with open(path, "r") as f:
        lines: list = f.readlines()
        return (lines[0].strip(), int(lines[1].strip()))

if __name__ == '__main__':
    main()