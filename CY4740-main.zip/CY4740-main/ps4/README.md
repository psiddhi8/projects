# Secure Chat
## Usage
### Server
`python secure_server.py -sp [port]` 
* Client defaults to port `9090`
### Client
`python secure_client.py`
 * enter username and password exactly as provided in `password_file` to login.
## Commands
### `list`
* Lists all logged in clients.
### `send [username] [message]`
* Sends the supplied message to the supplied username, establishing a connection if one doesn't already exist.
### Other
* `CTRL+C` to log out.