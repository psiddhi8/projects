from secure_base import SecureBase
import argparse,os
import logging
import socket
from select import select
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
import secure_logging
import json

MAX_MSG_LEN: int = 65535  # The maximum length of a message that can be sent over the network
G: int = 2

secure_logger = secure_logging.create_logger('server')

class SecureServer(SecureBase):
    _users: list[dict] # socket, username, c1, shared key 
    # The constructor for the SecureServer class.
    def __init__(self, server_port: int) -> None:
        # Checking if the port number is valid. If not, exit the program with an error.
        if not 0 < server_port < 65536:
            secure_logger.critical("The port number must be between 1 and 65535.")
            print("The port number must be between 0 and 65535.")
            secure_logger.debug(f"Given port: {server_port}")
            exit(1)

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Creating a TCP socket
        self._sock.bind(('', server_port))                              # And binding it to the specified port on localhost
        self._sock.listen()                                          
        secure_logger.info("Server initialized...")
        secure_logger.debug(f"Server port: {server_port}")
        
        self._users = []
        try:
            self._server_private_key = self.read_key("server_private_key.pem", "private")
        except Exception as e:
            secure_logger.error(f"Error reading server private key. {e}")
            exit(1)
        self._p = self._load_p("p.txt")
        self._run()

    def _run(self) -> None:
        try:
            clients = [self._sock]  # Initial list containing only the server socket
            while True:
                clients = [client for client in clients if client.fileno() != -1]
                readable, _, _ = select(clients, [], [])
                for sock in readable:
                    if sock is self._sock:
                        # New connection
                        secure_logger.info("Received a new connection.")
                        client_sock, addr = self._sock.accept()
                        try:
                            self._new_client(client_sock, addr)
                            secure_logger.info("New client authenticated.")
                            clients.append(client_sock)
                        except ValueError as e:
                            secure_logger.warning("Invalid credentials.")
                            secure_logger.debug(e)
                            continue
                    else:
                        # Existing connection has data
                        data = sock.recv(MAX_MSG_LEN)
                        if len(data) == 0:
                            continue

                        addr = sock.getpeername()
                        client = [client for client in self._users if client['ip'] == addr[0] and client['port'] == addr[1]]
                        if len(client) > 0:
                            client = client[0]
                            if client['c_1'] is None:
                                secure_logger.info(f"{client['username']} is already logged in.")
                                self._handle_message(data, client)
                            else:    
                                secure_logger.info(f"Verifying c1 for {client['username']}.")
                                self._verify_c1(data, client)
                        else:
                            print("close socket.")
                            sock.close()
                            clients.remove(sock)
                            
        except KeyboardInterrupt:
            secure_logger.debug("Received KeyboardInterrupt.")
            secure_logger.info("Server shutting down...")
            print("\nServer shutting down...")
            self._sock.close()

    # This function starts the authentication process with the client.
    def _new_client(self, sock: socket.socket, addr: tuple) -> None:
        secure_logger.info(f"New connection from {addr}.")
        data = sock.recv(MAX_MSG_LEN)
        if len(data) == 0:
            return

        plaintext: bytes = self._server_private_key.decrypt(
            data,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        g_a = int.from_bytes(plaintext[:256])   
        username = plaintext[256:].decode()

        try:
            gW: int = self._get_password(username)
            secure_logger.info(f"User {username} found.")
        except ValueError as e:
            byte_string = b"ERROR: Invalid credentials."
            sock.send(byte_string)
            secure_logger.error(f"User {username} not found. {e}.")
            raise ValueError("Invalid credentials.")

        b: int = int.from_bytes(os.urandom(128))
        u: int = int.from_bytes(os.urandom(4))
        
        # Compute Shared Key
        g_uW = pow(gW, u, self._p)
        g_auW = (g_a * g_uW) % self._p
        shared_key: int = pow(g_auW, b, self._p)  

        c_1: int = int.from_bytes(os.urandom(8)) # 8 bytes
        self._users.append({
            'socket': sock,
            'ip': addr[0],
            'port': addr[1],
            'username': username,
            'shared_key': shared_key,
            'c_1': c_1
            })
        
        g_b: int = pow(G, b, self._p)
        
        gb_bytes: bytes = int.to_bytes(g_b, 256)
        u_bytes: bytes = int.to_bytes(u, 4)
        c1_bytes: bytes = int.to_bytes(c_1, 8)
        
        message_bytes: bytes = [gb_bytes, u_bytes, c1_bytes]
        message_bytes = b''.join(message_bytes)
        
        signature: bytes = self._server_private_key.sign(
            message_bytes,
            asym_padding.PSS(
                mgf=asym_padding.MGF1(hashes.SHA256()),
                salt_length=asym_padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        final_message = message_bytes + signature
        secure_logger.info(f"Sending handshake message 1 to user {username}.")
        sock.send(final_message)
   
    # This function reads the associated g^W for the password from the file and returns it.     
    def _get_password(self, username) -> int:
        with open("users_data.txt", 'r') as file:
            for line in file:
                # Split the line into username and value parts
                line_username, value = line.strip().split(':')
                if line_username == username:
                    return int(value)
                    
        secure_logger.warning("Username was not found in file.")
        raise ValueError("Invalid Credentials.")

    # This function handles a message sent by the client.
    def _handle_message(self, data: bytes, client: dict) -> None:
        msg = self._get_decrypted_message(data, client["shared_key"])
        if msg['type'] == 'LIST':
            secure_logger.info(f"Received LIST message from {client['username']}.")
            self._send_list(client)
            secure_logger.info(f"Sent LIST message to {client['username']}.")
        elif msg['type'] == 'SHARED KEY':
            secure_logger.info(f"Received SHARED KEY message from {client['username']}.")
            self._send_shared_key(msg, client)
            secure_logger.info(f"Sent SHARED KEY message to {client['username']}.")
        elif msg['type'] == 'PORT':
            secure_logger.info(f"Received PORT message from {client['username']}.")
            self._save_listening_port(msg, client)
            secure_logger.info(f"Saved PORT message from {client['username']}.")
        elif msg['type'] == 'SIGN-OUT':
            secure_logger.info(f"Received SIGN OUT message from {client['username']}.")
            client['socket'].close()
            self._users.remove(client)
            secure_logger.info(f"Removed {client['username']} from the list of users.")
        secure_logger.info(f"Message from {client['username']} handled.")

    # This function decrypts the message sent by the client using the shared key.
    def _get_decrypted_message(self, data: bytes, shared_key: int) -> dict:
        secure_logger.info("Decrypting message.")
        mac, iv, tag, encrypted_message = self._symm_data_format(data)
        dec_msg = self._symm_key_dec(encrypted_message, mac, iv, tag, shared_key)
        return json.loads(dec_msg.decode())

    # This verifies the c1 value sent by the client, if it is correct, user has logged in successfully.   
    def _verify_c1(self, data: bytes, client: dict) -> None:
        mac, iv, tag, encrypted_data = self._symm_data_format(data)
        c_1_bytes: bytes = encrypted_data[:8]
        c_2: bytes = encrypted_data[8:]

        unencrypted_c1 = self._symm_key_dec(c_1_bytes, mac, iv, tag, client["shared_key"])
        c_1 = int.from_bytes(unencrypted_c1)

        if c_1 == client["c_1"]:
            client['c_1'] = None
            (mac, iv, tag, encrypted_list) = self._symm_key_enc(c_2, client["shared_key"])
            client['socket'].send(mac+iv+tag+encrypted_list)
            secure_logger.info(f"User {client['username']} has logged in.")
            self._send_list(client)
        else:
            secure_logger.error(f"User {client['username']} failed to log in.")
            secure_logger.debug(f"Expected c1: {client['c_1']}, Received c1: {c_1}")

    # This sends a list of all users who are logged.
    def _send_list(self, client: dict) -> None:
        usernames_logged_in: list = [user['username'] for user in self._users if user['c_1'] is None]
        list_msg: dict = {
            "type": "LIST",
            "users": usernames_logged_in}
        self._send(list_msg, client)

    # This starts sends the shared key in the Needham Schroeder Key Establishment Protocol
    def _send_shared_key(self, msg: dict, client: dict) -> None:
        matching_users: list = [user for user in self._users if user['c_1'] is None and user['username'] == msg['peer']]

        if len(matching_users) == 0:
            msg_table: dict = {
                "type": "ERROR",
                "error": "User not found",
                "peer": msg["peer"],
            }
            self._send(msg_table, client)
            secure_logger.debug(f"{client['username']}'s is not logged in.")
            return
        secure_logger.info(f"Sending shared key between {msg['my_name']} and {msg['peer']} to {msg['my_name']}.")

        symm_key_int: int = int.from_bytes(os.urandom(32))
        b_msg: bytes = json.dumps({
                "username": client["username"],
                "shared_key": symm_key_int
            }).encode()
        
        (mac, iv, tag, enc_msg) = self._symm_key_enc(b_msg, matching_users[0]["shared_key"])
        ttb_bytes: bytes = mac+iv+tag+enc_msg

        msg_table: dict = {
            "type": "SHARED KEY",
            "nonce": msg["nonce"],
            "username": matching_users[0]["username"],
            "shared_key": symm_key_int,
            "TTB": int.from_bytes(ttb_bytes), 
            "ttb_len": len(ttb_bytes),
            "ip": matching_users[0]["ip"],
            "port": matching_users[0]["l_port"]
        }

        self._send(msg_table, client)
        secure_logger.info(f"Shared key sent from server to {client['username']} for {matching_users[0]["username"]}.")

    
    # This function saves the listening port of the client.
    def _save_listening_port(self, msg: dict, client: dict) -> None:
        port = msg["port"]
        client["l_port"] = port
        secure_logger.info(f"Listening Port saved for {client['username']}.")

    # This encrypts the message using the shared key and sends to client.    
    def _send(self, msg: dict, client: dict) -> None:
        msg_table: bytes = json.dumps(msg).encode()
        (mac, iv, tag, encrypted_list) = self._symm_key_enc(msg_table, client["shared_key"])
        client['socket'].send(mac+iv+tag+encrypted_list)
        
def main():
    # Creating a parser for the command line arguments
    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        prog='secure_server',
        description='A server responsible for coordinating chat messages between clients.'
    )
    parser.add_argument("-sp", type = int, help = "The port the server will run on", dest = "server_port", required = True)
    args: argparse.Namespace = parser.parse_args()

    SecureServer(args.server_port)

if __name__ == '__main__':
    main()





